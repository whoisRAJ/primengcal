import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import {EventService} from './eventservice';

@Component({
  selector: 'app-full-calendar',
  templateUrl: './full-calendar.component.html',
  styleUrls: ['./full-calendar.component.css']
})
export class FullCalendarComponent implements OnInit {

  events: any[];
  options: any;
  header: any;
  constructor(){}
  //constructor(private eventService: EventService) { }

  ngOnInit() {
    this.events = [
    {
      "title": "UK-Stansted-Year End Day",
      "start": "2018-12-31"
    },

    {
      "title": "New Year's Day",
      "start": "2019-01-01"
    },
    {
      "title": "Makar Sankranti / Pongal",
      "start": "2019-01-08",
      "end": "2019-01-10"
    },
    {
      "title": "Independence Day",
      "start": "2019-01-18"
    },
    {
      "title": "Ganesh Chaturthi",
      "start": "2019-01-18"
    },
    {
      "title": "Holi",
      "start": "2019-01-18"
    }
    ];

    
    //this.eventService.getEvents().subscribe(events => {[this.events = events]; console.log(events);});
    this.options = {     
      plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
      defaultDate: '2019-01-01',
      header: {
        left: 'prev,next',
        center: 'title'
       // right: 'dayGridMonth,timeGridWeek,timeGridDay'
      },
      editable: true
    };
  }

}
